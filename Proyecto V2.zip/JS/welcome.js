setTimeout(function() {
    window.location.href = "ellas+bellas.php";
}, 3000);