<?php
    $direccion_BBDD="localhost";
	$nombre_BBDD="centro_estetica";
	$usuario_BBDD="root";
	$contra_BBDD="";
?>